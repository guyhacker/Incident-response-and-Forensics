# **MemLabs Lab 1 - Beginner's Luck**

## **Challenge description**

My sister's computer crashed. We were very fortunate to recover this memory dump. Your job is get all her important files from the system. From what we remember, we suddenly saw a black window pop up with some thing being executed. When the crash happened, she was trying to draw something. Thats all we remember from the time of crash.

**Note**: This challenge is composed of 3 flags.

**Challenge file**: [MemLabs_Lab1](https://mega.nz/#!6l4BhKIb!l8ATZoliB_ULlvlkESwkPiXAETJEF7p91Gf9CWuQI70)

## **Challenge file hash**

The commpressed archive
+ MD5 hash: 919a0ded944c427b7f4e5c26a6790e8d

The memory dump
+ MD5 hash: b9fec1a443907d870cb32b048bda9380

Please follow the [flag submission rules](https://github.com/stuxnet999/MemLabs#flag-submission) when sending the email for solution verification.